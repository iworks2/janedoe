import TestBackend from './implementation';
import AuthenticationPage from './AuthenticationPage';

export const DecapCmsBackendTest = {
  TestBackend,
  AuthenticationPage,
};
export { TestBackend, AuthenticationPage };
