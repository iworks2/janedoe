import GitGatewayBackend from './implementation';

export const DecapCmsBackendGitGateway = {
  GitGatewayBackend,
};
export { GitGatewayBackend };
