import { DecapCmsCore as CMS } from 'decap-cms-core';
import { en } from 'decap-cms-locales';

CMS.registerLocale('en', en);
