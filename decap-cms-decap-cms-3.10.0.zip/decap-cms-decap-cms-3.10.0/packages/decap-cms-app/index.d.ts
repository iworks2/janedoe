declare module 'decap-cms-app' {
  import type { CMS } from 'decap-cms-core';

  export const DecapCmsApp: CMS;

  export default DecapCmsApp;
}
